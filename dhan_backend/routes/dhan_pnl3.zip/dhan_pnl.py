

#########################################################################################################################
# from flask import Blueprint, jsonify
# from flask_socketio import emit
# from config import client_id, access_token
# from db import get_db_connection
# from extensions import socketio
# import requests
# import time
# import mysql.connector
# from apscheduler.schedulers.background import BackgroundScheduler

# # ✅ Blueprint for PnL Report API
# pnl_report_bp = Blueprint("pnl_report", __name__)

# # ✅ Dhan API Configuration
# DHAN_LTP_URL = "https://api.dhan.co/v2/marketfeed/ltp"
# HEADERS = {
#     "Accept": "application/json",
#     "Content-Type": "application/json",
#     "access-token": access_token,
#     "client-id": client_id,
# }

# # ✅ Caching and Rate Limit Handling
# live_price_cache = {}
# last_updated_time = 0
# CACHE_REFRESH_INTERVAL = 30  # Refresh every 30 seconds

# def fetch_with_backoff(url, payload, headers, max_retries=5):
#     delay = 1
#     for attempt in range(max_retries):
#         try:
#             response = requests.post(url, json=payload, headers=headers)
#             response.raise_for_status()
#             return response.json()
#         except requests.exceptions.RequestException as e:
#             if "429" in str(e):
#                 print(f"⚠️ Rate limited. Retrying in {delay} seconds...")
#                 time.sleep(delay)
#                 delay *= 2
#             else:
#                 print(f"❌ API Request Failed: {e}")
#                 return None
#     return None

# # ✅ Fetch Executed Orders from Database
# def get_orders_from_db():
#     connection = None
#     orders = []
#     try:
#         connection = get_db_connection()
#         cursor = connection.cursor(dictionary=True)
#         cursor.execute("SELECT order_id, security_id, transaction_type, quantity, price FROM offline_order WHERE status = 'EXECUTED'")
#         orders = cursor.fetchall()

#         for order in orders:
#             if float(order["price"]) == 0.00:
#                 security_id = order["security_id"]
#                 order["price"] = live_price_cache.get(security_id, 0.0)
#     except mysql.connector.Error as e:
#         print(f"Database error: {e}")
#     except Exception as e:
#         print(f"Unexpected error: {e}")
#     finally:
#         if connection:
#             connection.close()
#     return orders

# # ✅ Fetch Live Prices with Caching
# def get_live_prices(security_ids):
#     global last_updated_time, live_price_cache
#     if time.time() - last_updated_time < CACHE_REFRESH_INTERVAL:
#         print("🟢 Using cached prices...")
#         return {sid: live_price_cache.get(sid, 0.0) for sid in security_ids}
    
#     if not security_ids:
#         return {}
    
#     url = DHAN_LTP_URL
#     payload = {"NSE_EQ": [int(sid) for sid in security_ids]}
#     data = fetch_with_backoff(url, payload, HEADERS)
#     if not data:
#         return {}
    
#     live_prices = {}
#     if "data" in data and "NSE_EQ" in data["data"]:
#         for sid in security_ids:
#             if str(sid) in data["data"]["NSE_EQ"]:
#                 live_prices[sid] = float(data["data"]["NSE_EQ"][str(sid)]["last_price"])
    
#     live_price_cache = live_prices
#     last_updated_time = time.time()
#     return live_prices

# # ✅ Stream PnL via WebSockets
# def stream_pnl():
#     print("✅ PnL stream started.", flush=True)
#     while True:
#         orders = get_orders_from_db()
#         if not orders:
#             print("⚠️ No executed orders found.", flush=True)
#             time.sleep(5)
#             continue

#         security_ids = list(set(order["security_id"] for order in orders))
#         live_prices = get_live_prices(security_ids)
#         if not live_prices:
#             print("⚠️ Live price data is empty.", flush=True)
#             time.sleep(5)
#             continue

#         pnl_report = []
#         total_pnl = 0.0
#         for order in orders:
#             try:
#                 security_id = order["security_id"]
#                 entry_price = float(order["price"])
#                 quantity = int(order["quantity"])
#                 transaction_type = order["transaction_type"]
#                 live_price = live_prices.get(security_id, 0.0)

#                 pnl = (live_price - entry_price) * quantity
#                 if transaction_type == "SELL":
#                     pnl = (entry_price - live_price) * quantity

#                 total_pnl += pnl
#                 pnl_report.append({
#                     "order_id": order["order_id"],
#                     "security_id": security_id,
#                     "entry_price": entry_price,
#                     "current_price": live_price,
#                     "quantity": quantity,
#                     "transaction_type": transaction_type,
#                     "pnl": round(pnl, 2),
#                     "pnl_percentage": round((pnl / (entry_price * quantity)) * 100, 2) if entry_price * quantity else 0,
#                 })
#             except Exception as e:
#                 print(f"❌ Error processing order {order}: {e}", flush=True)

#         socketio.emit("pnl_update", {"status": "success", "pnl_report": pnl_report, "total_pnl": round(total_pnl, 2)})
#         print("✅ Sent live PnL data to frontend.", flush=True)
#         time.sleep(5)

# # ✅ API Endpoint to Fetch PnL Report
# @pnl_report_bp.route("/pnl-report", methods=["GET"])
# def pnl_report():
#     orders = get_orders_from_db()
#     security_ids = [order["security_id"] for order in orders] if orders else []
#     live_prices = get_live_prices(security_ids)
#     return jsonify({"status": "success", "orders": orders, "live_prices": live_prices})

# # ✅ Schedule PnL Streaming as a Background Task
# scheduler = BackgroundScheduler()
# scheduler.add_job(stream_pnl, "interval", seconds=5)
# scheduler.start()


#########################################################################################################################


# import asyncio
# import time
# import requests
# import mysql.connector
# from flask import Blueprint, jsonify
# from flask_socketio import emit
# from config import client_id, access_token
# from db import get_db_connection
# from extensions import socketio 

# # ✅ Blueprint for PnL Report API
# pnl_report_bp = Blueprint("pnl_report", __name__)

# # ✅ Dhan API Configuration
# DHAN_LTP_URL = "https://api.dhan.co/v2/marketfeed/ltp"
# HEADERS = {
#     "Accept": "application/json",
#     "Content-Type": "application/json",
#     "access-token": access_token,
#     "client-id": client_id,
# }

# # ✅ Caching & Rate Limit Handling
# live_price_cache = {}
# last_updated_time = 0

# def fetch_with_backoff(url, payload, headers, max_retries=5):
#     """Handles API requests with exponential backoff."""
#     delay = 1
#     for attempt in range(max_retries):
#         try:
#             response = requests.post(url, json=payload, headers=headers)
#             response.raise_for_status()
#             return response.json()
#         except requests.exceptions.RequestException as e:
#             if "429" in str(e):
#                 print(f"⚠️ Rate limited. Retrying in {delay} seconds...")
#                 time.sleep(delay)
#                 delay *= 2
#             else:
#                 print(f"❌ API Request Failed: {e}")
#                 return None
#     return None

# # ✅ Fetch Executed Orders from Database
# def get_orders_from_db():
#     """Fetch executed offline orders from the database."""
#     connection = None
#     orders = []
#     try:
#         connection = get_db_connection()
#         cursor = connection.cursor(dictionary=True)
#         cursor.execute("SELECT order_id, security_id, transaction_type, quantity, price FROM offline_order WHERE status = 'EXECUTED'")
#         orders = cursor.fetchall()

#         for order in orders:
#             if float(order["price"]) == 0.00:
#                 security_id = order["security_id"]
#                 order["price"] = live_price_cache.get(security_id, 0.0)
#     except mysql.connector.Error as e:
#         print(f"Database error: {e}")
#     except Exception as e:
#         print(f"Unexpected error: {e}")
#     finally:
#         if connection:
#             connection.close()
#     return orders

# # ✅ Fetch Live Prices Instantly (No Caching)
# def get_live_prices(security_ids):
#     """Fetch real-time live prices without caching."""
#     if not security_ids:
#         return {}

#     url = DHAN_LTP_URL
#     payload = {"NSE_EQ": [int(sid) for sid in security_ids]}
#     data = fetch_with_backoff(url, payload, HEADERS)
#     if not data:
#         return {}

#     live_prices = {}
#     if "data" in data and "NSE_EQ" in data["data"]:
#         for sid in security_ids:
#             if str(sid) in data["data"]["NSE_EQ"]:
#                 live_prices[sid] = float(data["data"]["NSE_EQ"][str(sid)]["last_price"])
    
#     return live_prices

# # ✅ Stream PnL Updates Every Millisecond
# async def stream_pnl():
#     """Continuously stream PnL updates in real-time."""
#     print("✅ PnL stream started.", flush=True)
#     while True:
#         orders = get_orders_from_db()
#         if not orders:
#             print("⚠️ No executed orders found.", flush=True)
#             await asyncio.sleep(0.001)  # ✅ Sleep 1 millisecond before retrying
#             continue

#         security_ids = list(set(order["security_id"] for order in orders))
#         live_prices = get_live_prices(security_ids)
#         if not live_prices:
#             print("⚠️ Live price data is empty.", flush=True)
#             await asyncio.sleep(0.001)  # ✅ Retry after 1ms
#             continue

#         pnl_report = []
#         total_pnl = 0.0
#         for order in orders:
#             try:
#                 security_id = order["security_id"]
#                 entry_price = float(order["price"])
#                 quantity = int(order["quantity"])
#                 transaction_type = order["transaction_type"]
#                 live_price = live_prices.get(security_id, 0.0)

#                 pnl = (live_price - entry_price) * quantity
#                 if transaction_type == "SELL":
#                     pnl = (entry_price - live_price) * quantity

#                 total_pnl += pnl
#                 pnl_report.append({
#                     "order_id": order["order_id"],
#                     "security_id": security_id,
#                     "entry_price": entry_price,
#                     "current_price": live_price,
#                     "quantity": quantity,
#                     "transaction_type": transaction_type,
#                     "pnl": round(pnl, 2),
#                     "pnl_percentage": round((pnl / (entry_price * quantity)) * 100, 2) if entry_price * quantity else 0,
#                 })
#             except Exception as e:
#                 print(f"❌ Error processing order {order}: {e}", flush=True)

#         socketio.emit("pnl_update", {"status": "success", "pnl_report": pnl_report, "total_pnl": round(total_pnl, 2)}, broadcast=True)
#         print("✅ Sent live PnL data to frontend.", flush=True)

#         await asyncio.sleep(0.001)  # ✅ Sleep for 1 millisecond

# # ✅ API Endpoint to Fetch PnL Report
# @pnl_report_bp.route("/pnl-report", methods=["GET"])
# def pnl_report():
#     """Returns the latest PnL report data."""
#     orders = get_orders_from_db()
#     security_ids = [order["security_id"] for order in orders] if orders else []
#     live_prices = get_live_prices(security_ids)
#     return jsonify({"status": "success", "orders": orders, "live_prices": live_prices})

# # ✅ Start PnL Streaming Task
# def start_pnl_stream():
#     """Starts the async PnL streaming task."""
#     loop = asyncio.new_event_loop()
#     asyncio.set_event_loop(loop)
#     loop.create_task(stream_pnl())  # ✅ Runs in background
#     loop.run_forever()
 





# ========================================================================================================================


# from flask import Blueprint, jsonify
# from flask_socketio import emit
# from config import client_id, access_token
# from db import get_db_connection
# from extensions import socketio
# import requests
# import time
# import mysql.connector
# from apscheduler.schedulers.background import BackgroundScheduler

# # ✅ Blueprint for PnL Report API
# pnl_report_bp = Blueprint("pnl_report", __name__)

# # ✅ Dhan API Configuration
# # DHAN_LTP_URL = "https://api.dhan.co/v2/marketfeed/ltp"
# DHAN_BASE_URL = "https://api.dhan.co/v2/marketfeed/ltp"


# HEADERS = {
#     "Accept": "application/json",
#     "Content-Type": "application/json",
#     "access-token": access_token,
#     "client-id": client_id,
# }

# # ✅ Caching and Rate Limit Handling
# live_price_cache = {}
# last_updated_time = 0
# CACHE_REFRESH_INTERVAL = 30  # Refresh every 30 seconds

# def fetch_with_backoff(url, payload, headers, max_retries=5):
#     delay = 1
#     for attempt in range(max_retries):
#         try:
#             response = requests.post(url, json=payload, headers=headers)
#             response.raise_for_status()
#             return response.json()
#         except requests.exceptions.RequestException as e:
#             if "429" in str(e):
#                 print(f"⚠️ Rate limited. Retrying in {delay} seconds...")
#                 time.sleep(delay)
#                 delay *= 2
#             else:
#                 print(f"❌ API Request Failed: {e}")
#                 return None
#     return None

# # ✅ Fetch Executed Orders from Database
# def get_orders_from_db():
#     connection = None
#     orders = []
#     try:
#         connection = get_db_connection()
#         cursor = connection.cursor(dictionary=True)
#         cursor.execute("SELECT order_id, security_id, transaction_type, quantity, price FROM offline_order WHERE status = 'EXECUTED'")
#         orders = cursor.fetchall()

#         for order in orders:
#             if float(order["price"]) == 0.00:
#                 security_id = order["security_id"]
#                 order["price"] = live_price_cache.get(security_id, 0.0)
#     except mysql.connector.Error as e:
#         print(f"Database error: {e}")
#     except Exception as e:
#         print(f"Unexpected error: {e}")
#     finally:
#         if connection:
#             connection.close()
#     return orders

# # ✅ Fetch Live Prices with Caching
# def get_live_prices(security_ids):
#     global last_updated_time, live_price_cache
#     if time.time() - last_updated_time < CACHE_REFRESH_INTERVAL:
#         # print("🟢 Using cached prices...",live_price_cache)
#         return {sid: live_price_cache.get(sid, 0.0) for sid in security_ids}
    
#     if not security_ids:
#         return {}
    
#     url = DHAN_BASE_URL
#     payload = {"NSE_EQ": [int(sid) for sid in security_ids]}
#     data = fetch_with_backoff(url, payload, HEADERS)
#     if not data:
#         return {}
    
#     live_prices = {}
#     if "data" in data and "NSE_EQ" in data["data"]:
#         for sid in security_ids:
#             if str(sid) in data["data"]["NSE_EQ"]:
#                 live_prices[sid] = float(data["data"]["NSE_EQ"][str(sid)]["last_price"])
    
#     live_price_cache = live_prices
#     print("🟢 live_price_cache----------------",live_price_cache)
#     last_updated_time = time.time()
#     return live_prices

# # ✅ Stream PnL via WebSockets
# def stream_pnl():
#     print("✅ PnL stream started.", flush=True)
#     while True:
#         orders = get_orders_from_db()
#         if not orders:
#             print("⚠️ No executed orders found.", flush=True)
#             time.sleep(5)
#             continue

#         security_ids = list(set(order["security_id"] for order in orders))
#         live_prices = get_live_prices(security_ids)
#         print("🟢 live_prices-------++++++++---------",live_prices)
#         if not live_prices:
#             print("⚠️ Live price data is empty.", flush=True)
#             time.sleep(5)
#             continue

#         pnl_report = []
#         total_pnl = 0.0
#         for order in orders:
#             try:
#                 security_id = order["security_id"]
#                 entry_price = float(order["price"])
#                 quantity = int(order["quantity"])
#                 transaction_type = order["transaction_type"]
#                 live_price = live_prices.get(security_id, 0.0)

#                 pnl = (live_price - entry_price) * quantity
#                 if transaction_type == "SELL":
#                     pnl = (entry_price - live_price) * quantity

#                 total_pnl += pnl
#                 pnl_report.append({
#                     "order_id": order["order_id"],
#                     "security_id": security_id,
#                     "entry_price": entry_price,
#                     "current_price": live_price,
#                     "quantity": quantity,
#                     "transaction_type": transaction_type,
#                     "pnl": round(pnl, 2),
#                     "pnl_percentage": round((pnl / (entry_price * quantity)) * 100, 2) if entry_price * quantity else 0,
#                 })
#             except Exception as e:
#                 print(f"❌ Error processing order {order}: {e}", flush=True)

#         socketio.emit("pnl_update", {"status": "success", "pnl_report": pnl_report, "total_pnl": round(total_pnl, 2)})
#         print("✅ Sent live PnL data to frontend.", flush=True)
#         time.sleep(5)

# # ✅ API Endpoint to Fetch PnL Report
# @pnl_report_bp.route("/pnl-report", methods=["GET"])
# def pnl_report():
#     orders = get_orders_from_db()
#     security_ids = [order["security_id"] for order in orders] if orders else []
#     live_prices = get_live_prices(security_ids)
#     return jsonify({"status": "success", "orders": orders, "live_prices": live_prices})

# # ✅ Schedule PnL Streaming as a Background Task
# scheduler = BackgroundScheduler()
# scheduler.add_job(stream_pnl, "interval", seconds=5)
# scheduler.start()

# ========================================================================================================================













# from flask import Blueprint, jsonify
# from flask_socketio import emit
# from config import client_id, access_token
# from db import get_db_connection
# from extensions import socketio
# import threading
# import mysql.connector
# import websocket
# import json
# import requests
# import time

# pnl_report_bp = Blueprint("pnl_report", __name__)

# # ✅ WebSocket & API Configuration
# DHAN_WS_URL = "wss://api-feed.dhan.co"

# HEADERS = {
#     "Accept": "application/json",
#     "Content-Type": "application/json",
#     "access-token": access_token,
#     "client-id": client_id,
# }

# DHAN_BASE_URL = "https://api.dhan.co/v2/marketfeed/ltp"

# UNKNOWN_SECURITIES = set()  # Cache of invalid security IDs
# live_price_cache = {}  # Store fetched prices
# # ✅ Initialize global variables
# last_updated_time = 0  # Timestamp for caching
# CACHE_REFRESH_INTERVAL = 10  # Cache duration in seconds




# def fetch_with_backoff(url, payload, headers, max_retries=5):
#     delay = 1
#     for attempt in range(max_retries):
#         try:
#             response = requests.post(url, json=payload, headers=headers)
#             response.raise_for_status()
#             return response.json()
#         except requests.exceptions.RequestException as e:
#             if "429" in str(e):
#                 print(f"⚠️ Rate limited. Retrying in {delay} seconds...")
#                 time.sleep(delay)
#                 delay *= 2
#             else:
#                 print(f"❌ API Request Failed: {e}")
#                 return None
#     return None

# # ✅ Function to Fetch Live Price (Fixed Version)
# # ✅ Function to Fetch Live Price (Fixed Version)
# def get_live_prices(security_ids):
#     global last_updated_time, live_price_cache

#     if time.time() - last_updated_time < CACHE_REFRESH_INTERVAL:
#         print("🟢 Using cached prices...", live_price_cache)
#         return {sid: live_price_cache.get(str(sid), 0.0) for sid in security_ids}

#     # ✅ Fetch missing prices via API only if not found in cache
#     missing_ids = [sid for sid in security_ids if str(sid) not in live_price_cache]
#     if not missing_ids:
#         return {sid: live_price_cache[str(sid)] for sid in security_ids}

#     url = DHAN_BASE_URL
#     payload = {"NSE_EQ": missing_ids}
#     data = fetch_with_backoff(url, payload, HEADERS)
    
#     if not data or "data" not in data or "NSE_EQ" not in data["data"]:
#         return {}

#     # ✅ Update Cache
#     for sid in missing_ids:
#         sid_str = str(sid)
#         if sid_str in data["data"]["NSE_EQ"]:
#             live_price_cache[sid_str] = float(data["data"]["NSE_EQ"][sid_str]["last_price"])

#     last_updated_time = time.time()
#     return {sid: live_price_cache.get(str(sid), 0.0) for sid in security_ids}


# # ✅ WebSocket Handlers
# def on_message(ws, message):
#     print("🟢 WebSocket message received.")
#     try:
#         data = json.loads(message)
#         if "data" in data:
#             for item in data["data"]:
#                 security_id = str(item.get("security_id"))  # Ensure it's a string
#                 last_price = float(item.get("ltp", 0.0))

#                 if security_id and last_price > 0:
#                     live_price_cache[security_id] = last_price
#                     print(f"✅ Updated LTP: {security_id} -> {last_price}")

#         # ✅ Emit PnL update only if prices changed
#         if live_price_cache:
#             emit_pnl_update()
    
#     except Exception as e:
#         print(f"❌ WebSocket message error: {e}")


# def on_open(ws):
#     print("✅ WebSocket connected. Fetching security IDs...")

#     # ✅ Fetch security IDs from database
#     connection = get_db_connection()
#     cursor = connection.cursor()
#     cursor.execute("SELECT DISTINCT security_id FROM offline_order WHERE status = 'EXECUTED'")
#     security_ids = [str(row[0]) for row in cursor.fetchall()]
#     connection.close()

#     if not security_ids:
#         print("⚠️ No security IDs found to subscribe.")
#         return

#     # ✅ Subscribe to live price updates
#     subscription_message = {
#         "operation": "subscribe",
#         "data": {"symbols": security_ids}  # ✅ Pass actual security IDs
#     }
#     ws.send(json.dumps(subscription_message))
#     print(f"🟢 Subscribed to LTP updates for {len(security_ids)} symbols.")


# def start_websocket():
#     retry_delay = 1  # Start with 1 second delay
#     while True:
#         try:
#             ws = websocket.WebSocketApp(DHAN_WS_URL, on_message=on_message)
#             ws.on_open = on_open
#             ws.run_forever()
#             retry_delay = 1  # Reset delay on successful connection
#         except Exception as e:
#             print(f"❌ WebSocket Connection Error: {e}")
#             print(f"🔄 Retrying WebSocket in {retry_delay} seconds...")
#             time.sleep(retry_delay)
#             retry_delay = min(retry_delay * 2, 30)  # Exponential backoff (max 30s)


# # ✅ Fetch Executed Orders
# # ✅ Fetch Executed Orders
# def get_orders():
#     connection = get_db_connection()
#     cursor = connection.cursor(dictionary=True)
#     cursor.execute("SELECT order_id, security_id, transaction_type, quantity, price FROM offline_order WHERE status = 'EXECUTED'")
#     orders = cursor.fetchall()
    
#     for order in orders:
#         security_id = order["security_id"]
#         entry_price = float(order["price"])
        
#         # ✅ If price is 0, fetch from API
#         if entry_price == 0.00:
#             fetched_price = get_live_prices([security_id])  # 🔹 Fix function call
#             order["price"] = fetched_price.get(security_id, 0.0)  # 🔹 Get price safely

#         # ✅ Ensure the latest price is updated
#         if security_id not in live_price_cache:
#             fetched_price = get_live_prices([security_id])  # 🔹 Fix function call
#             live_price_cache[security_id] = fetched_price.get(security_id, 0.0)

#     connection.close()
#     return orders

# # ✅ Emit PnL Updates
# def emit_pnl_update():
#     orders = get_orders()
#     pnl_report = []
#     total_pnl = 0.0

#     for order in orders:
#         security_id = order["security_id"]
#         entry_price = float(order["price"])
#         quantity = int(order["quantity"])
#         transaction_type = order["transaction_type"]
#         live_price = live_price_cache.get(security_id) or get_live_prices(security_id)

#         if live_price is None:
#             print(f"⚠️ Skipping PnL calculation for {security_id} (No price data)")
#             continue  # Skip this order

#         pnl = (live_price - entry_price) * quantity if transaction_type == "BUY" else (entry_price - live_price) * quantity
#         total_pnl += pnl

#         pnl_report.append({
#             "order_id": order["order_id"],
#             "security_id": security_id,
#             "entry_price": entry_price,
#             "current_price": live_price,
#             "quantity": quantity,
#             "transaction_type": transaction_type,
#             "pnl": round(pnl, 2),
#             "pnl_percentage": round((pnl / (entry_price * quantity)) * 100, 2) if entry_price * quantity else 0,
#         })

#     socketio.emit("pnl_update", {"status": "success", "pnl_report": pnl_report, "total_pnl": round(total_pnl, 2)})
#     print("✅ Sent live PnL data to frontend.")

# # ✅ API Endpoint
# @pnl_report_bp.route("/pnl-report", methods=["GET"])
# def pnl_report():
#     orders = get_orders()
#     # live_price_cache[security_id] = last_price
#     # print("🟢 live_price_cache----------------",live_price_cache)
#     # return jsonify({"status": "success", "orders": orders, "live_prices": live_price_cache})
#     return jsonify({
#     "status": "success",
#     "orders": orders,
#     "live_prices": {str(k): v for k, v in live_price_cache.items()}  # 🔹 Convert keys to strings
#     })







# from flask import Blueprint, jsonify
# from flask_socketio import emit
# from config import client_id, access_token
# from db import get_db_connection
# from extensions import socketio
# import requests
# import time
# import mysql.connector
# from apscheduler.schedulers.background import BackgroundScheduler

# # ✅ Blueprint for PnL Report API
# pnl_report_bp = Blueprint("pnl_report", __name__)

# # ✅ Dhan API Configuration
# DHAN_MARKETFEED_URL = "https://api.dhan.co/v2/marketfeed/ltp"
# DHAN_BASE_URL = "https://api.dhan.co/v2/orders"


# HEADERS = {
#     "Accept": "application/json",
#     "Content-Type": "application/json",
#     "access-token": access_token,
#     "client-id": client_id,
# }

# # ✅ Caching and Rate Limit Handling
# live_price_cache = {}
# last_updated_time = 0
# CACHE_REFRESH_INTERVAL = 30  # Refresh every 30 seconds

# def fetch_with_backoff(url, payload, headers, max_retries=5):
#     delay = 1
#     for attempt in range(max_retries):
#         try:
#             response = requests.post(url, json=payload, headers=headers)
#             response.raise_for_status()
#             return response.json()
#         except requests.exceptions.RequestException as e:
#             if "429" in str(e):
#                 print(f"⚠️ Rate limited. Retrying in {delay} seconds...")
#                 time.sleep(delay)
#                 delay *= 2
#             else:
#                 print(f"❌ API Request Failed: {e}")
#                 return None
#     return None

# # ✅ Fetch Executed Orders from Database
# def get_orders_from_db():
#     connection = None
#     orders = []
#     try:
#         connection = get_db_connection()
#         cursor = connection.cursor(dictionary=True)
#         cursor.execute("SELECT order_id, security_id, transaction_type, quantity, price FROM offline_order WHERE status = 'EXECUTED'")
#         orders = cursor.fetchall()

#         for order in orders:
#             if float(order["price"]) == 0.00:
#                 security_id = order["security_id"]
#                 order["price"] = live_price_cache.get(security_id, 0.0)
#     except mysql.connector.Error as e:
#         print(f"Database error: {e}")
#     except Exception as e:
#         print(f"Unexpected error: {e}")
#     finally:
#         if connection:
#             connection.close()
#     return orders

# # ✅ Fetch Live Prices with Caching
# def get_live_prices(security_ids):
#     global last_updated_time, live_price_cache
#     if time.time() - last_updated_time < CACHE_REFRESH_INTERVAL:
#         # print("🟢 Using cached prices...",live_price_cache)
#         return {sid: live_price_cache.get(sid, 0.0) for sid in security_ids}
    
#     if not security_ids:
#         return {}
    
#     url = DHAN_MARKETFEED_URL
#     payload = {"NSE_EQ": [int(sid) for sid in security_ids]}
#     data = fetch_with_backoff(url, payload, HEADERS)
#     if not data:
#         return {}
    
#     live_prices = {}
#     if "data" in data and "NSE_EQ" in data["data"]:
#         for sid in security_ids:
#             if str(sid) in data["data"]["NSE_EQ"]:
#                 live_prices[sid] = float(data["data"]["NSE_EQ"][str(sid)]["last_price"])
    
#     live_price_cache = live_prices
#     print("🟢 live_price_cache----------------",live_price_cache)
#     last_updated_time = time.time()
#     return live_prices


# def stream_pnl():
#     print("✅ PnL stream started.", flush=True)
    
#     while True:
#         orders = get_orders_from_db()
#         if not orders:
#             print("⚠️ No executed orders found.", flush=True)
#             time.sleep(5)
#             continue

#         security_ids = list(set(order["security_id"] for order in orders))
#         live_prices = get_live_prices(security_ids)
#         print("🟢 live_prices:", live_prices)

#         if not live_prices:
#             print("⚠️ Live price data is empty.", flush=True)
#             time.sleep(5)
#             continue

#         pnl_report = []
#         total_pnl = 0.0

#         for order in orders:
#             try:
#                 security_id = order["security_id"]
#                 entry_price = float(order["price"])
#                 quantity = int(order["quantity"])
#                 transaction_type = order["transaction_type"]
#                 live_price = live_prices.get(security_id, 0.0)

#                 # Calculate PnL
#                 pnl = (live_price - entry_price) * quantity
#                 if transaction_type == "SELL":
#                     pnl = (entry_price - live_price) * quantity

#                 # Calculate PnL Percentage
#                 pnl_percentage = round((pnl / (entry_price * quantity)) * 100, 2) if entry_price * quantity else 0

#                 # ✅ Auto-Sell Check
#                 # if transaction_type == "BUY":
#                 #     if pnl_percentage >= 2:
#                 #         print(f"🚀 Profit Target Reached ({pnl_percentage}%)! Selling Order: {security_id}")
#                 #         place_sell_order(security_id, quantity, live_price)

#                 #     elif pnl_percentage <= -2:
#                 #         print(f"⚠️ Stop-Loss Hit ({pnl_percentage}%)! Selling Order: {security_id}")
#                 #         place_sell_order(security_id, quantity, live_price)

#                 total_pnl += pnl
#                 pnl_report.append({
#                     "order_id": order["order_id"],
#                     "security_id": security_id,
#                     "entry_price": entry_price,
#                     "current_price": live_price,
#                     "quantity": quantity,
#                     "transaction_type": transaction_type,
#                     "pnl": round(pnl, 2),
#                     "pnl_percentage": pnl_percentage,
#                 })

#             except Exception as e:
#                 print(f"❌ Error processing order {order}: {e}", flush=True)

#         # Emit data to frontend
#         socketio.emit("pnl_update", {"status": "success", "pnl_report": pnl_report, "total_pnl": round(total_pnl, 2)})
#         print("✅ Sent live PnL data to frontend.", flush=True)

#         time.sleep(5)
# # ✅ API Endpoint to Fetch PnL Report
# @pnl_report_bp.route("/pnl-report", methods=["GET"])
# def pnl_report():
#     orders = get_orders_from_db()
#     security_ids = [order["security_id"] for order in orders] if orders else []
#     live_prices = get_live_prices(security_ids)
#     return jsonify({"status": "success", "orders": orders, "live_prices": live_prices})

# # ✅ Schedule PnL Streaming as a Background Task
# scheduler = BackgroundScheduler()
# scheduler.add_job(stream_pnl, "interval", seconds=5)
# scheduler.start()














from flask import Blueprint, jsonify
from flask_socketio import emit
from config import client_id, access_token
from db import get_db_connection
from extensions import socketio
import websocket
import json
import struct
import threading
import logging
import mysql.connector

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

pnl_report_bp = Blueprint("pnl_report", __name__)
live_price_cache = {}

ws_url = f"wss://api-feed.dhan.co?version=2&token={access_token}&clientId={client_id}&authType=2"

def get_orders_from_db():
    connection = None
    orders = []
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT order_id, security_id, transaction_type, quantity, price FROM offline_order WHERE status = 'EXECUTED'")
        orders = cursor.fetchall()
        for order in orders:
            if float(order["price"]) == 0.00:
                order["price"] = live_price_cache.get(order["security_id"], 0.0)
    except mysql.connector.Error as e:
        logger.error(f"Database error: {e}")
    finally:
        if connection:
            connection.close()
    return orders

def on_open(ws):
    logger.info("WebSocket opened")
    update_subscriptions(ws)
    

def on_message(ws, message):
    global live_price_cache
    logger.info(f"Raw message length: {len(message)} bytes")

    if isinstance(message, bytes) and len(message) >= 12:
        try:
            # Extract bytes
            sec_id_bytes = message[4:8]
            ltp_bytes = message[8:12]

            # Log extracted byte values
            logger.info(f"Raw bytes (4-7): {sec_id_bytes.hex()}, (8-11): {ltp_bytes.hex()}")

            # Try Big-Endian first
            security_id_be = struct.unpack('>I', sec_id_bytes)[0]
            last_price_be = struct.unpack('>f', ltp_bytes)[0]

            # Try Little-Endian as a backup
            security_id_le = struct.unpack('<I', sec_id_bytes)[0]
            last_price_le = struct.unpack('<f', ltp_bytes)[0]

            # Choose valid security_id and price
            security_id = str(security_id_be) if security_id_be < 100000 else str(security_id_le)
            last_price = last_price_be if 0 < last_price_be < 1000000 else last_price_le

            # Round price to 2 decimal places
            last_price = round(last_price, 2)

            logger.info(f"Parsed - Security ID: {security_id}, LTP: {last_price}")

            # Store in cache only if valid
            if 0 < last_price < 1000000:
                live_price_cache[security_id] = last_price
                
                # Log formatted cache
                formatted_prices = {key: round(value, 2) for key, value in live_price_cache.items()}
                logger.info(f"Updated live_price_cache: {formatted_prices}")

                # Stream updated PnL
                stream_pnl()
            else:
                logger.warning(f"Invalid price detected: {last_price}")

        except Exception as e:
            logger.error(f"Parsing error: {e}")


def on_error(ws, error):
    logger.error(f"WebSocket error: {error}")

def on_close(ws, code, reason):
    logger.info(f"WebSocket closed: {code}, {reason}")

def update_subscriptions(ws):
    orders = get_orders_from_db()
    if not orders:
        logger.info("No executed orders to subscribe to")
        return
    security_ids = list(set(order["security_id"] for order in orders))
    subscription = {
        "RequestCode": 15,
        "InstrumentCount": len(security_ids),
        "InstrumentList": [{"ExchangeSegment": "NSE_EQ", "SecurityId": sid} for sid in security_ids]
    }
    subscription_json = json.dumps(subscription)
    ws.send(subscription_json)
    logger.info(f"Subscription sent: {subscription_json}")
    logger.info(f"Subscribed to: {security_ids}")

def stream_pnl():
    orders = get_orders_from_db()
    if not orders:
        socketio.emit("pnl_update", {"status": "error", "message": "No executed orders found"})
        return
    pnl_report = []
    total_pnl = 0.0
    for order in orders:
        try:
            security_id = order["security_id"]
            entry_price = float(order["price"])
            quantity = int(order["quantity"])
            transaction_type = order["transaction_type"]
            live_price = live_price_cache.get(security_id, 0.0)
            pnl = (live_price - entry_price) * quantity if transaction_type == "BUY" else (entry_price - live_price) * quantity
            pnl_percentage = round((pnl / (entry_price * quantity)) * 100, 2) if entry_price * quantity else 0
            total_pnl += pnl
            pnl_report.append({
                "order_id": order["order_id"],
                "security_id": security_id,
                "entry_price": entry_price,
                "current_price": live_price,
                "quantity": quantity,
                "transaction_type": transaction_type,
                "pnl": round(pnl, 2),
                "pnl_percentage": pnl_percentage,
            })
        except Exception as e:
            logger.error(f"Error processing order {order}: {e}")
    # socketio.emit("pnl_update", {"status": "success", "pnl_report": pnl_report, "total_pnl": round(total_pnl, 2)})
    logger.info("Sent live PnL data to frontend")

@pnl_report_bp.route("/pnl-report", methods=["GET"])
def pnl_report():
    orders = get_orders_from_db()
    security_ids = [order["security_id"] for order in orders] if orders else []
    live_prices = {sid: live_price_cache.get(sid, 0.0) for sid in security_ids}
    logger.info(f"Returning PnL report: orders={len(orders)}, live_prices={live_prices}")
    return jsonify({"status": "success", "orders": orders, "live_prices": live_prices})

def start_websocket():
    logger.info("Starting WebSocket...")
    ws = websocket.WebSocketApp(ws_url, on_open=on_open, on_message=on_message, on_error=on_error, on_close=on_close)
    ws.run_forever(ping_interval=10)

websocket_thread = threading.Thread(target=start_websocket, daemon=True)
websocket_thread.start()






# from flask import Blueprint, jsonify
# from flask_socketio import emit
# from config import client_id, access_token
# from db import get_db_connection
# from extensions import socketio
# import websocket
# import json
# import struct
# import threading
# import logging
# import mysql.connector

# logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# logger = logging.getLogger(__name__)

# pnl_report_bp = Blueprint("pnl_report", __name__)
# live_price_cache = {}
# websocket_thread = None

# ws_url = f"wss://api-feed.dhan.co?version=2&token={access_token}&clientId={client_id}&authType=2"

# def get_orders_from_db():
#     connection = None
#     orders = []
#     try:
#         connection = get_db_connection()
#         cursor = connection.cursor(dictionary=True)
#         cursor.execute("SELECT order_id, security_id, transaction_type, quantity, price FROM offline_order WHERE status = 'EXECUTED'")
#         orders = cursor.fetchall()
#         for order in orders:
#             if float(order["price"]) == 0.00:
#                 order["price"] = live_price_cache.get(order["security_id"], 0.0)
#     except mysql.connector.Error as e:
#         logger.error(f"Database error: {e}")
#     finally:
#         if connection:
#             connection.close()
#     return orders

# def on_open(ws):
#     logger.info("WebSocket opened")
#     update_subscriptions(ws)

# def on_message(ws, message):
#     global live_price_cache
#     logger.info(f"Raw message length: {len(message)} bytes")
#     if isinstance(message, bytes) and len(message) >= 12:
#         try:
#             sec_id_bytes = message[4:8]
#             ltp_bytes = message[8:12]
#             logger.info(f"Raw bytes (4-7): {sec_id_bytes.hex()}, (8-11): {ltp_bytes.hex()}")

#             security_id_be = struct.unpack('>I', sec_id_bytes)[0]
#             last_price_be = struct.unpack('>f', ltp_bytes)[0]
#             security_id_le = struct.unpack('<I', sec_id_bytes)[0]
#             last_price_le = struct.unpack('<f', ltp_bytes)[0]

#             security_id = str(security_id_be) if security_id_be < 100000 else str(security_id_le)
#             last_price = last_price_be if 0 < last_price_be < 1000000 else last_price_le
#             last_price = round(last_price, 2)

#             logger.info(f"Parsed - Security ID: {security_id}, LTP: {last_price}")

#             if 0 < last_price < 1000000:
#                 live_price_cache[security_id] = last_price
#                 formatted_prices = {key: round(value, 2) for key, value in live_price_cache.items()}
#                 logger.info(f"Updated live_price_cache: {formatted_prices}")
#                 stream_pnl()
#             else:
#                 logger.warning(f"Invalid price detected: {last_price}")
#         except Exception as e:
#             logger.error(f"Parsing error: {e}")

# def on_error(ws, error):
#     logger.error(f"WebSocket error: {error}")

# def on_close(ws, code, reason):
#     logger.info(f"WebSocket closed: {code}, {reason}")

# def update_subscriptions(ws):
#     orders = get_orders_from_db()
#     if not orders:
#         logger.info("No executed orders to subscribe to")
#         return
#     security_ids = list(set(order["security_id"] for order in orders))
#     subscription = {
#         "RequestCode": 15,
#         "InstrumentCount": len(security_ids),
#         "InstrumentList": [{"ExchangeSegment": "NSE_EQ", "SecurityId": sid} for sid in security_ids]
#     }
#     subscription_json = json.dumps(subscription)
#     ws.send(subscription_json)
#     logger.info(f"Subscription sent: {subscription_json}")
#     logger.info(f"Subscribed to: {security_ids}")

# def stream_pnl():
#     orders = get_orders_from_db()
#     if not orders:
#         socketio.emit("pnl_update", {"status": "error", "message": "No executed orders found"})
#         return
#     pnl_report = []
#     total_pnl = 0.0
#     for order in orders:
#         try:
#             security_id = order["security_id"]
#             entry_price = float(order["price"])
#             quantity = int(order["quantity"])
#             transaction_type = order["transaction_type"]
#             live_price = live_price_cache.get(security_id, 0.0)
#             pnl = (live_price - entry_price) * quantity if transaction_type == "BUY" else (entry_price - live_price) * quantity
#             pnl_percentage = round((pnl / (entry_price * quantity)) * 100, 2) if entry_price * quantity else 0
#             total_pnl += pnl
#             pnl_report.append({
#                 "order_id": order["order_id"],
#                 "security_id": security_id,
#                 "entry_price": entry_price,
#                 "current_price": live_price,
#                 "quantity": quantity,
#                 "transaction_type": transaction_type,
#                 "pnl": round(pnl, 2),
#                 "pnl_percentage": pnl_percentage,
#             })
#         except Exception as e:
#             logger.error(f"Error processing order {order}: {e}")
#     socketio.emit("pnl_update", {"status": "success", "pnl_report": pnl_report, "total_pnl": round(total_pnl, 2)})
#     logger.info("Sent live PnL data to frontend",)

# @pnl_report_bp.route("/pnl-report", methods=["GET"])
# def pnl_report():
#     orders = get_orders_from_db()
#     security_ids = [order["security_id"] for order in orders] if orders else []
#     live_prices = {sid: live_price_cache.get(sid, 0.0) for sid in security_ids}
#     logger.info(f"Returning PnL report: orders={len(orders)}, live_prices={live_prices}")
#     return jsonify({"status": "success", "orders": orders, "live_prices": live_prices})

# def start_websocket():
#     global websocket_thread
#     if websocket_thread is None or not websocket_thread.is_alive():
#         logger.info("Starting WebSocket...")
#         ws = websocket.WebSocketApp(ws_url, on_open=on_open, on_message=on_message, on_error=on_error, on_close=on_close)
#         websocket_thread = threading.Thread(target=ws.run_forever, kwargs={"ping_interval": 10}, daemon=True)
#         websocket_thread.start()
#     else:
#         logger.info("WebSocket already running")

# start_websocket()







# from flask import Blueprint, jsonify
# from flask_socketio import SocketIO, emit as socketio_emit
# from config import client_id, access_token
# from db import get_db_connection
# from extensions import socketio
# import websocket
# import json
# import struct
# import threading
# import logging
# import mysql.connector
# import time

# logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# logger = logging.getLogger(__name__)

# pnl_report_bp = Blueprint("pnl_report", __name__)
# live_price_cache = {}
# websocket_thread = None

# ws_url = f"wss://api-feed.dhan.co?version=2&token={access_token}&clientId={client_id}&authType=2"

# def get_orders_from_db():
#     connection = None
#     orders = []
#     try:
#         connection = get_db_connection()
#         cursor = connection.cursor(dictionary=True)
#         cursor.execute("SELECT order_id, security_id, transaction_type, quantity, price FROM offline_order WHERE status = 'EXECUTED'")
#         orders = cursor.fetchall()
#         for order in orders:
#             if float(order["price"]) == 0.00:
#                 order["price"] = live_price_cache.get(order["security_id"], 0.0)
#     except mysql.connector.Error as e:
#         logger.error(f"Database error: {e}")
#     finally:
#         if connection:
#             connection.close()
#     return orders

# def on_open(ws):
#     logger.info("WebSocket opened")
#     update_subscriptions(ws)

# def on_message(ws, message):
#     global live_price_cache
#     logger.info(f"Raw message length: {len(message)} bytes")
#     if isinstance(message, bytes) and len(message) >= 12:
#         try:
#             sec_id_bytes = message[4:8]
#             ltp_bytes = message[8:12]
#             logger.info(f"Raw bytes (4-7): {sec_id_bytes.hex()}, (8-11): {ltp_bytes.hex()}")

#             security_id_be = struct.unpack('>I', sec_id_bytes)[0]
#             last_price_be = struct.unpack('>f', ltp_bytes)[0]
#             security_id_le = struct.unpack('<I', sec_id_bytes)[0]
#             last_price_le = struct.unpack('<f', ltp_bytes)[0]

#             security_id = str(security_id_be) if security_id_be < 100000 else str(security_id_le)
#             last_price = last_price_be if 0 < last_price_be < 1000000 else last_price_le
#             last_price = round(last_price, 2)

#             logger.info(f"Parsed - Security ID: {security_id}, LTP: {last_price}")

#             if 0 < last_price < 1000000:
#                 live_price_cache[security_id] = last_price
#                 formatted_prices = {key: round(value, 2) for key, value in live_price_cache.items()}
#                 logger.info(f"Updated live_price_cache: {formatted_prices}")
#                 stream_pnl()
#             else:
#                 logger.warning(f"Invalid price detected: {last_price}")
#         except Exception as e:
#             logger.error(f"Parsing error: {e}")

# def on_error(ws, error):
#     logger.error(f"WebSocket error: {error}")

# def on_close(ws, code, reason):
#     logger.info(f"WebSocket closed: {code}, {reason}")
#     time.sleep(5)
#     start_websocket()

# def update_subscriptions(ws):
#     orders = get_orders_from_db()
#     if not orders:
#         logger.info("No executed orders to subscribe to")
#         return
#     security_ids = list(set(order["security_id"] for order in orders))
#     subscription = {
#         "RequestCode": 15,
#         "InstrumentCount": len(security_ids),
#         "InstrumentList": [{"ExchangeSegment": "NSE_EQ", "SecurityId": sid} for sid in security_ids]
#     }
#     subscription_json = json.dumps(subscription)
#     ws.send(subscription_json)
#     logger.info(f"Subscription sent: {subscription_json}")
#     logger.info(f"Subscribed to: {security_ids}")

# def stream_pnl():
#     orders = get_orders_from_db()
#     if not orders:
#         socketio.emit("pnl_update", {"status": "error", "message": "No executed orders found"}, namespace="/")
#         return
#     pnl_report = []
#     total_pnl = 0.0
#     for order in orders:
#         try:
#             security_id = order["security_id"]
#             entry_price = float(order["price"])
#             quantity = int(order["quantity"])
#             transaction_type = order["transaction_type"]
#             live_price = live_price_cache.get(security_id, 0.0)
#             pnl = (live_price - entry_price) * quantity if transaction_type == "BUY" else (entry_price - live_price) * quantity
#             pnl_percentage = round((pnl / (entry_price * quantity)) * 100, 2) if entry_price * quantity else 0
#             total_pnl += pnl
#             pnl_report.append({
#                 "order_id": order["order_id"],
#                 "security_id": security_id,
#                 "entry_price": entry_price,
#                 "current_price": live_price,
#                 "quantity": quantity,
#                 "transaction_type": transaction_type,
#                 "pnl": round(pnl, 2),
#                 "pnl_percentage": pnl_percentage,
#             })
#         except Exception as e:
#             logger.error(f"Error processing order {order}: {e}")
#     payload = {"status": "success", "pnl_report": pnl_report, "total_pnl": round(total_pnl, 2)}
#     logger.info(f"Emitting pnl_update on namespace '/': {payload}")
#     socketio.emit("pnl_update", payload, namespace="/")
#     socketio.emit("test_event", {"message": "Hello from backend"}, namespace="/")
#     logger.info("Sent live PnL data to frontend")

# @socketio.on("connect", namespace="/")
# def handle_connect():
#     logger.info("Client connected to namespace '/': emitting welcome")
#     socketio_emit("test_event", {"message": "Welcome new client!"}, namespace="/")

# @pnl_report_bp.route("/pnl-report", methods=["GET"])
# def pnl_report():
#     orders = get_orders_from_db()
#     security_ids = [order["security_id"] for order in orders] if orders else []
#     live_prices = {sid: live_price_cache.get(sid, 0.0) for sid in security_ids}
#     logger.info(f"Returning PnL report: orders={len(orders)}, live_prices={live_prices}")
#     return jsonify({"status": "success", "orders": orders, "live_prices": live_prices})

# def start_websocket():
#     global websocket_thread
#     if websocket_thread is None or not websocket_thread.is_alive():
#         logger.info("Starting WebSocket...")
#         ws = websocket.WebSocketApp(ws_url, on_open=on_open, on_message=on_message, on_error=on_error, on_close=on_close)
#         websocket_thread = threading.Thread(target=ws.run_forever, kwargs={"ping_interval": 10}, daemon=True)
#         websocket_thread.start()
#     else:
#         logger.info("WebSocket already running")

# start_websocket()


// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";

// const socket = io("http://127.0.0.1:5000", {
//     transports: ["websocket"], 
//     reconnectionAttempts: 5,   
//     reconnectionDelay: 2000,    
// });

// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [livePrices, setLivePrices] = useState({});  // ✅ Store live prices separately
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     const fetchInitialData = async () => {
//         try {
//             const response = await fetch("http://127.0.0.1:5000/api/pnl-report");
//             if (!response.ok) {
//                 throw new Error(`HTTP error! Status: ${response.status}`);
//             }
//             const data = await response.json();
//             console.log("✅ Initial API Data:", data);

//             if (data.status === "success") {
//                 setPnlData(data.orders || []);
//                 setLivePrices(data.live_prices || {});  // ✅ Store live prices separately
//             } else {
//                 throw new Error("Invalid API response structure.");
//             }
//         } catch (err) {
//             console.error("Error fetching initial data:", err);
//             setError("Failed to fetch initial data.");
//         }
//         setLoading(false);
//     };

//     useEffect(() => {
//         fetchInitialData();

//         const handlePnLUpdate = (data) => {
//             console.log("🔄 Received WebSocket Update:", data);

//             if (data.status === "success") {
//                 setPnlData((prevPnlData) => [...prevPnlData]); // ✅ Ensure re-render for table
//                 setLivePrices((prevLivePrices) => ({
//                     ...prevLivePrices,
//                     ...data.live_prices, // ✅ Merge new live prices
//                 }));
//             } else {
//                 setError("Invalid WebSocket data.");
//             }
//         };

//         socket.on("pnl_update", handlePnLUpdate);
//         socket.on("connect", () => console.log("✅ WebSocket connected!"));
//         socket.on("disconnect", () => console.log("❌ WebSocket disconnected!"));
//         socket.on("connect_error", (err) => {
//             console.error("WebSocket connection error:", err.message || err);
//             setError("WebSocket connection failed.");
//         });

//         return () => {
//             socket.off("pnl_update", handlePnLUpdate);
//         };
//     }, []);

//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
//             {loading ? (
//                 <p className="text-gray-300">Fetching data...</p>
//             ) : error ? (
//                 <p className="text-red-500 font-semibold">{error}</p>
//             ) : (
//                 <div className="w-full max-w-5xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th> {/* ✅ Fixed column */}
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="8" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => {
//                                         const currentPrice = livePrices[order.security_id] || "N/A"; // ✅ Fetch correct live price
//                                         return (
//                                             <tr key={order.order_id} className="hover:bg-gray-700">
//                                                 <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                                 <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                                 <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                                 <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                                 <td className="px-4 py-2">{order.price || "N/A"}</td>
//                                                 <td className="px-4 py-2">{currentPrice}</td> {/* ✅ Display Correct Live Price */}
//                                                 <td
//                                                     className={`px-4 py-2 font-bold text-lg ${
//                                                         order.pnl >= 0 ? "text-green-500" : "text-red-500"
//                                                     }`}
//                                                 >
//                                                     {order.pnl?.toFixed(2) || "N/A"}
//                                                 </td>
//                                                 <td className="px-4 py-2 font-semibold">
//                                                     {order.pnl_percentage?.toFixed(2) || "N/A"}%
//                                                 </td>
//                                             </tr>
//                                         );
//                                     })
//                                 )}
//                             </tbody>
//                         </table>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;






import React, { useEffect, useState, useCallback } from "react";
import { io } from "socket.io-client";

const socket = io("http://127.0.0.1:5000", {
    transports: ["websocket"], 
    reconnectionAttempts: 5,   
    reconnectionDelay: 2000,    
});

const PnlReport = () => {
    const [pnlData, setPnlData] = useState([]);
    const [livePrices, setLivePrices] = useState({});  
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const fetchInitialData = async () => {
        try {
            const response = await fetch("http://127.0.0.1:5000/api/pnl-report");
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const data = await response.json();
            console.log("✅ Initial API Data:", data);

            if (data.status === "success") {
                setPnlData(data.orders || []);
                setLivePrices(data.live_prices || {});
            } else {
                throw new Error("Invalid API response structure.");
            }
        } catch (err) {
            console.error("Error fetching initial data:", err);
            setError("Failed to fetch initial data.");
        }
        setLoading(false);
    };

    const handlePnLUpdate = useCallback((data) => {
        console.log("🔄 WebSocket Received Update:", data);

        if (data.status === "success" && data.live_prices) {
            setLivePrices(prevLivePrices => ({
                ...prevLivePrices,
                ...data.live_prices,
            }));
        } else {
            setError("Invalid WebSocket data.");
        }
    }, []);

    useEffect(() => {
        fetchInitialData();

        socket.on("pnl_update", handlePnLUpdate);
        socket.on("connect", () => console.log("✅ WebSocket connected!"));
        socket.on("disconnect", () => console.log("❌ WebSocket disconnected!"));
        socket.on("connect_error", (err) => {
            console.error("WebSocket connection error:", err.message || err);
            setError("WebSocket connection failed.");
        });

        return () => {
            socket.off("pnl_update", handlePnLUpdate);
        };
    }, [handlePnLUpdate]);

    return (
        <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
            <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
            {loading ? (
                <p className="text-gray-300">Fetching data...</p>
            ) : error ? (
                <p className="text-red-500 font-semibold">{error}</p>
            ) : (
                <div className="w-full max-w-5xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-gray-300">
                            <thead className="bg-blue-600 text-white uppercase text-xs">
                                <tr>
                                    <th className="px-4 py-2">Order ID</th>
                                    <th className="px-4 py-2">Security ID</th>
                                    <th className="px-4 py-2">Type</th>
                                    <th className="px-4 py-2">Quantity</th>
                                    <th className="px-4 py-2">Entry Price</th>
                                    <th className="px-4 py-2">Latest Price</th>
                                    <th className="px-4 py-2">PnL</th>
                                    <th className="px-4 py-2">PnL %</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-700">
                                {pnlData.length === 0 ? (
                                    <tr>
                                        <td colSpan="8" className="p-4 text-center text-gray-500">
                                            No orders available.
                                        </td>
                                    </tr>
                                ) : (
                                    pnlData.map((order) => {
                                        const currentPrice = livePrices[order.security_id] || "N/A";
                                        return (
                                            <tr key={order.order_id} className="hover:bg-gray-700">
                                                <td className="px-4 py-2">{order.order_id || "N/A"}</td>
                                                <td className="px-4 py-2">{order.security_id || "N/A"}</td>
                                                <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
                                                <td className="px-4 py-2">{order.quantity || "N/A"}</td>
                                                <td className="px-4 py-2">{order.price || "N/A"}</td>
                                                <td className="px-4 py-2 text-yellow-400 font-semibold">{currentPrice}</td>
                                                <td className={`px-4 py-2 font-bold text-lg ${order.pnl >= 0 ? "text-green-500" : "text-red-500"}`}>
                                                    {order.pnl?.toFixed(2) || "N/A"}
                                                </td>
                                                <td className="px-4 py-2 font-semibold">
                                                    {order.pnl_percentage?.toFixed(2) || "N/A"}%
                                                </td>
                                            </tr>
                                        );
                                    })
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
};

export default PnlReport;










// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";


// // ✅ Fix: Force WebSocket transport
// const socket = io("http://127.0.0.1:5000", {
//     transports: ["websocket"],  // ✅ Use WebSockets only
//     reconnectionAttempts: 5,    // Retry up to 5 times
//     reconnectionDelay: 2000,    // Wait 2 seconds between attempts
// });

// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     // Fetch initial data from Flask API
//     const fetchInitialData = async () => {
//         try {
//             const response = await fetch("http://127.0.0.1:5000/api/pnl-report");
//             console.log("📡 Fetching initial data...");  // ✅ Logging API call
//             if (!response.ok) {
//                 throw new Error(`HTTP error! Status: ${response.status}`);
//             }
//             const data = await response.json();
//             console.log("✅ Initial API Data:", data);  // ✅ Print API response in console
//             if (data.status === "success" && Array.isArray(data.orders)) {
//                 setPnlData(data.orders); // Initial data from API
//             } else {
//                 throw new Error("Invalid API response structure.");
//             }
//         } catch (err) {
//             console.error("Error fetching initial data:", err);
//             setError("Failed to fetch initial data. Check the console for details.");
//         }
//         setLoading(false);
//     };

//     useEffect(() => {
//         fetchInitialData(); // Fetch initial orders from Flask

//         // WebSocket event listeners
//         const handlePnLUpdate = (data) => {
//             console.log("🔄 Received WebSocket Update:", data);  // ✅ Print WebSocket data
//             console.log("Received PnL update:", data);
//             if (data.status === "success" && Array.isArray(data.pnl_report)) {
//                 setPnlData(data.pnl_report); // Update live data
//             } else {
//                 console.error("Invalid WebSocket data:", data);
//                 setError("Invalid WebSocket data.");
//             }
//         };

//         const handleConnect = () => console.log("✅ WebSocket connected!");
//         const handleDisconnect = () => console.log("❌ WebSocket disconnected!");
//         const handleError = (err) => {
//             console.error("WebSocket connection error:", err.message || err);
//             setError("WebSocket connection failed. Check the console for details.");
//         };

//         // Register WebSocket listeners
//         socket.on("pnl_update", handlePnLUpdate);
//         socket.on("connect", handleConnect);
//         socket.on("disconnect", handleDisconnect);
//         socket.on("connect_error", handleError);

//         return () => {
//             // Cleanup WebSocket listeners
//             socket.off("pnl_update", handlePnLUpdate);
//             socket.off("connect", handleConnect);
//             socket.off("disconnect", handleDisconnect);
//             socket.off("connect_error", handleError);
//         };
//     }, []);

//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
//             {loading ? (
//                 <p className="text-gray-300">Fetching data...</p>
//             ) : error ? (
//                 <p className="text-red-500 font-semibold">{error}</p>
//             ) : (
//                 <div className="w-full max-w-5xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th>
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="8" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => (
//                                         <tr key={order.order_id} className="hover:bg-gray-700">
//                                             <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.price || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.live_prices || "N/A"}</td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold text-lg ${
//                                                     order.pnl >= 0 ? "text-green-500" : "text-red-500"
//                                                 }`}
//                                             >
//                                                 {order.pnl?.toFixed(2) || "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.pnl_percentage?.toFixed(2) || "N/A"}%
//                                             </td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                         </table>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;














// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";

// const socket = io("http://127.0.0.1:5000"); // Connect WebSocket to Flask backend

// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     // Fetch initial data from Flask API
//     const fetchInitialData = async () => {
//         try {
//             const response = await fetch("http://127.0.0.1:5000/api/pnl-report");
//             const data = await response.json();
//             if (data.status === "success" && Array.isArray(data.orders)) {
//                 setPnlData(data.orders); // Initial data from API
//             } else {
//                 setError("Invalid API response structure.");
//             }
//         } catch (err) {
//             setError("API request failed.");
//         }
//         setLoading(false);
//     };

//     useEffect(() => {
//         fetchInitialData(); // Fetch initial orders from Flask

//         // Listen for live PnL updates from WebSocket
//         socket.on("pnl_update", (data) => {
//             if (data.status === "success" && Array.isArray(data.pnl_report)) {
//                 setPnlData(data.pnl_report); // Update live data
//             } else {
//                 setError("Invalid WebSocket data.");
//             }
//         });

//         socket.on("connect_error", (err) => {
//             console.error("Socket connection error:", err);
//             setError("WebSocket connection failed.");
//         });

//         return () => {
//             socket.off("pnl_update");
//             socket.off("connect_error");
//         };
//     }, []);

//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
//             {loading ? (
//                 <p className="text-gray-300">Fetching data...</p>
//             ) : error ? (
//                 <p className="text-red-500 font-semibold">{error}</p>
//             ) : (
//                 <div className="w-full max-w-5xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th>
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="8" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => (
//                                         <tr key={order.order_id} className="hover:bg-gray-700">
//                                             <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.entry_price !== undefined ? order.price : "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.current_price !== undefined ? order.current_price.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold text-lg ${
//                                                     order.pnl >= 0 ? "text-green-500" : "text-red-500"
//                                                 }`}
//                                             >
//                                                 {order.pnl !== undefined ? order.pnl.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.pnl_percentage !== undefined ? order.pnl_percentage.toFixed(2) : "N/A"}%
//                                             </td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                         </table>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;





// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";


// // ✅ Fix: Force WebSocket transport
// const socket = io("http://127.0.0.1:5000", {
//     transports: ["websocket"],  // ✅ Use WebSockets only
//     reconnectionAttempts: 5,    // Retry up to 5 times
//     reconnectionDelay: 2000,    // Wait 2 seconds between attempts
// });


// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     // Fetch initial data from Flask API
//     const fetchInitialData = async () => {
//         try {
//             const response = await fetch("http://127.0.0.1:5000/api/pnl-report");
//             if (!response.ok) {
//                 throw new Error(`HTTP error! Status: ${response.status}`);
//             }
//             const data = await response.json();
//             if (data.status === "success" && Array.isArray(data.orders)) {
//                 setPnlData(data.orders); // Initial data from API
//             } else {
//                 throw new Error("Invalid API response structure.");
//             }
//         } catch (err) {
//             console.error("Error fetching initial data:", err);
//             setError("Failed to fetch initial data. Check the console for details.");
//         }
//         setLoading(false);
//     };

//     useEffect(() => {
//         fetchInitialData(); // Fetch initial orders from Flask

//         // WebSocket event listeners
//         const handlePnLUpdate = (data) => {
//             console.log("Received PnL update:", data);
//             if (data.status === "success" && Array.isArray(data.pnl_report)) {
//                 setPnlData(data.pnl_report); // Update live data
//             } else {
//                 console.error("Invalid WebSocket data:", data);
//                 setError("Invalid WebSocket data.");
//             }
//         };

//         const handleConnect = () => console.log("✅ WebSocket connected!");
//         const handleDisconnect = () => console.log("❌ WebSocket disconnected!");
//         const handleError = (err) => {
//             console.error("WebSocket connection error:", err.message || err);
//             setError("WebSocket connection failed. Check the console for details.");
//         };

//         // Register WebSocket listeners
//         socket.on("pnl_update", handlePnLUpdate);
//         socket.on("connect", handleConnect);
//         socket.on("disconnect", handleDisconnect);
//         socket.on("connect_error", handleError);

//         return () => {
//             // Cleanup WebSocket listeners
//             socket.off("pnl_update", handlePnLUpdate);
//             socket.off("connect", handleConnect);
//             socket.off("disconnect", handleDisconnect);
//             socket.off("connect_error", handleError);
//         };
//     }, []);

//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
//             {loading ? (
//                 <p className="text-gray-300">Fetching data...</p>
//             ) : error ? (
//                 <p className="text-red-500 font-semibold">{error}</p>
//             ) : (
//                 <div className="w-full max-w-5xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th>
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="8" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => (
//                                         <tr key={order.order_id} className="hover:bg-gray-700">
//                                             <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.price || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.current_price || "N/A"}</td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold text-lg ${
//                                                     order.pnl >= 0 ? "text-green-500" : "text-red-500"
//                                                 }`}
//                                             >
//                                                 {order.pnl?.toFixed(2) || "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.pnl_percentage?.toFixed(2) || "N/A"}%
//                                             </td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                         </table>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;









// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";

// // ✅ WebSocket Setup
// const socket = io("http://127.0.0.1:5000", {
//     transports: ["websocket"],  // ✅ Use WebSockets only
//     reconnectionAttempts: 5,    // Retry up to 5 times
//     reconnectionDelay: 2000,    // Wait 2 seconds between attempts
// });

// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [totalPnl, setTotalPnl] = useState(0);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     // ✅ Fetch Initial Data from Flask API
//     const fetchInitialData = async () => {
//         try {
//             const response = await fetch("http://127.0.0.1:5000/pnl-report");
//             if (!response.ok) {
//                 throw new Error(`HTTP error! Status: ${response.status}`);
//             }
//             const data = await response.json();
//             if (data.status === "success" && Array.isArray(data.orders)) {
//                 setPnlData(data.orders); // Set initial orders data
//             } else {
//                 throw new Error("Invalid API response structure.");
//             }
//         } catch (err) {
//             console.error("Error fetching initial data:", err);
//             setError("Failed to fetch initial data. Check the console.");
//         }
//         setLoading(false);
//     };

//     useEffect(() => {
//         fetchInitialData(); // Fetch initial orders from Flask API

//         // ✅ WebSocket Event Listeners
//         const handlePnLUpdate = (data) => {
//             console.log("📊 Received PnL update:", data);
//             if (data.status === "success" && Array.isArray(data.pnl_report)) {
//                 setPnlData(data.pnl_report); // Update PnL data
//                 setTotalPnl(data.total_pnl); // Update Total PnL
//             } else {
//                 console.error("Invalid WebSocket data:", data);
//                 setError("Invalid WebSocket data.");
//             }
//         };

//         const handleConnect = () => console.log("✅ WebSocket connected!");
//         const handleDisconnect = () => console.log("❌ WebSocket disconnected!");
//         const handleError = (err) => {
//             console.error("WebSocket error:", err.message || err);
//             setError("WebSocket connection failed. Check the console.");
//         };

//         // Register WebSocket Listeners
//         socket.on("pnl_update", handlePnLUpdate);
//         socket.on("connect", handleConnect);
//         socket.on("disconnect", handleDisconnect);
//         socket.on("connect_error", handleError);

//         return () => {
//             // Cleanup WebSocket Listeners
//             socket.off("pnl_update", handlePnLUpdate);
//             socket.off("connect", handleConnect);
//             socket.off("disconnect", handleDisconnect);
//             socket.off("connect_error", handleError);
//         };
//     }, []);

//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>

//             {/* ✅ Show Errors & Loading State */}
//             {loading ? (
//                 <p className="text-gray-300">Fetching data...</p>
//             ) : error ? (
//                 <p className="text-red-500 font-semibold">{error}</p>
//             ) : (
//                 <div className="w-full max-w-5xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th>
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="8" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => (
//                                         <tr key={order.order_id} className="hover:bg-gray-700">
//                                             <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.entry_price?.toFixed(2) || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.current_price?.toFixed(2) || "N/A"}</td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold text-lg ${
//                                                     order.pnl >= 0 ? "text-green-500" : "text-red-500"
//                                                 }`}
//                                             >
//                                                 {order.pnl?.toFixed(2) || "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.pnl_percentage?.toFixed(2) || "N/A"}%
//                                             </td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                         </table>
//                     </div>
//                 </div>
//             )}

//             {/* ✅ Total PnL Summary */}
//             {!loading && !error && (
//                 <div className="mt-4 p-4 bg-gray-800 rounded-lg shadow-md w-full max-w-5xl">
//                     <h3 className="text-xl font-bold">
//                         Total PnL:{" "}
//                         <span className={totalPnl >= 0 ? "text-green-400" : "text-red-400"}>
//                             {totalPnl.toFixed(2)} INR
//                         </span>
//                     </h3>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;












// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";

// const API_URL = "http://127.0.0.1:5000";
// const socket = io(API_URL, {
//     transports: ["websocket"],
//     reconnectionAttempts: 5,
//     reconnectionDelay: 2000,
// });

// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [totalPnl, setTotalPnl] = useState(0);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     // Fetch Initial PnL Data from Flask API
//     const fetchInitialData = async () => {
//         try {
//             const response = await fetch(`${API_URL}/pnl-report`);
//             if (!response.ok) {
//                 throw new Error(`HTTP error! Status: ${response.status}`);
//             }
//             const data = await response.json();
//             if (data.status === "success" && Array.isArray(data.orders)) {
//                 setPnlData(data.orders);
//                 setTotalPnl(data.total_pnl || 0);
//             } else {
//                 throw new Error("Invalid API response structure.");
//             }
//         } catch (err) {
//             console.error("Error fetching initial data:", err);
//             setError("Failed to fetch initial data. Check the console.");
//         }
//         setLoading(false);
//     };

//     useEffect(() => {
//         fetchInitialData();

//         socket.on("pnl_update", (data) => {
//             console.log("📊 Received PnL update:", data);
//             if (data.status === "success" && Array.isArray(data.pnl_report)) {
//                 setPnlData(data.pnl_report);
//                 setTotalPnl(data.total_pnl);
//             } else {
//                 console.error("Invalid WebSocket data:", data);
//                 setError("Invalid WebSocket data.");
//             }
//         });

//         socket.on("connect", () => console.log("✅ WebSocket connected!"));
//         socket.on("disconnect", () => console.log("❌ WebSocket disconnected!"));
//         socket.on("connect_error", (err) => {
//             console.error("WebSocket error:", err.message || err);
//             setError("WebSocket connection failed. Check the console.");
//         });

//         return () => {
//             socket.off("pnl_update");
//             socket.off("connect");
//             socket.off("disconnect");
//             socket.off("connect_error");
//         };
//     }, []);

//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
//             {loading ? (
//                 <p className="text-gray-300">Fetching data...</p>
//             ) : error ? (
//                 <p className="text-red-500 font-semibold">{error}</p>
//             ) : (
//                 <div className="w-full max-w-5xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th>
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="8" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => (
//                                         <tr key={order.order_id} className="hover:bg-gray-700">
//                                             <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.price || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.current_price?.toFixed(2) || "N/A"}</td>
//                                             <td className={`px-4 py-2 font-bold text-lg ${order.pnl >= 0 ? "text-green-500" : "text-red-500"}`}>
//                                                 {order.pnl?.toFixed(2) || "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.pnl_percentage?.toFixed(2) || "N/A"}%
//                                             </td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                         </table>
//                     </div>
//                 </div>
//             )}

//             {!loading && !error && (
//                 <div className="mt-4 p-4 bg-gray-800 rounded-lg shadow-md w-full max-w-5xl">
//                     <h3 className="text-xl font-bold">
//                         Total PnL: <span className={totalPnl >= 0 ? "text-green-400" : "text-red-400"}>{totalPnl.toFixed(2)} INR</span>
//                     </h3>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;


























// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";

// const socket = io("http://127.0.0.1:5000"); // Connect WebSocket to Flask backend

// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     // Fetch initial data from Flask API
//     const fetchInitialData = async () => {
//         try {
//             const response = await fetch("http://127.0.0.1:5000/api/pnl-report");
//             if (!response.ok) {
//                 throw new Error(`HTTP error! Status: ${response.status}`);
//             }
//             const data = await response.json();
//             if (data.status === "success" && Array.isArray(data.orders)) {
//                 setPnlData(data.orders); // Initial data from API
//             } else {
//                 throw new Error("Invalid API response structure.");
//             }
//         } catch (err) {
//             console.error("Error fetching initial data:", err);
//             setError("Failed to fetch initial data. Check the console for details.");
//         }
//         setLoading(false);
//     };

//     useEffect(() => {
//         fetchInitialData(); // Fetch initial orders from Flask

//         // Listen for live PnL updates from WebSocket
//         socket.on("pnl_update", (data) => {
//             console.log("Received PnL update:", data);
//             if (data.status === "success" && Array.isArray(data.pnl_report)) {
//                 setPnlData(data.pnl_report); // Update live data
//             } else {
//                 console.error("Invalid WebSocket data:", data);
//                 setError("Invalid WebSocket data.");
//             }
//         });

//         socket.on("connect", () => {
//             console.log("WebSocket connected!");
//         });

//         socket.on("disconnect", () => {
//             console.log("WebSocket disconnected!");
//         });

//         socket.on("connect_error", (err) => {
//             console.error("Socket connection error:", err.message || err);
//             setError("WebSocket connection failed. Check the console for details.");
//         });

//         return () => {
//             socket.off("pnl_update");
//             socket.off("connect_error");
//         };
//     }, []);

//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
//             {loading ? (
//                 <p className="text-gray-300">Fetching data...</p>
//             ) : error ? (
//                 <p className="text-red-500 font-semibold">{error}</p>
//             ) : (
//                 <div className="w-full max-w-5xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th>
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="8" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => (
//                                         <tr key={order.order_id} className="hover:bg-gray-700">
//                                             <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.price || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.last_price || "N/A"}</td>

//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.entry_price?.toFixed(2) || "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.current_price?.toFixed(2) || "N/A"}
//                                             </td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold text-lg ${
//                                                     order.pnl >= 0 ? "text-green-500" : "text-red-500"
//                                                 }`}
//                                             >
//                                                 {order.pnl?.toFixed(2) || "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.pnl_percentage?.toFixed(2) || "N/A"}%
//                                             </td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                         </table>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;






// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";

// const socket = io(process.env.REACT_APP_SOCKET_URL || "http://127.0.0.1:5000"); // Connect WebSocket to Flask backend

// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     // Fetch initial data from Flask API
//     const fetchInitialData = async () => {
//         try {
//             const response = await fetch("http://127.0.0.1:5000/api/pnl-report");
//             if (!response.ok) {
//                 throw new Error(`HTTP error! Status: ${response.status}`);
//             }
//             const data = await response.json();
//             if (data.status === "success" && Array.isArray(data.orders)) {
//                 setPnlData(data.orders); // Initial data from API
//             } else {
//                 throw new Error("Invalid API response structure.");
//             }
//         } catch (err) {
//             console.error("Error fetching initial data:", err);
//             setError("Failed to fetch initial data. Check the console for details.");
//         }
//         setLoading(false);
//     };

//     useEffect(() => {
//         fetchInitialData(); // Fetch initial orders from Flask

//         // Listen for live PnL updates from WebSocket
//         socket.on("pnl_update", (data) => {
//             console.log("Received PnL update:", data);
//             if (data?.status === "success" && Array.isArray(data?.pnl_report)) {
//                 setPnlData(data.pnl_report); // Update live data
//             } else {
//                 console.error("Invalid WebSocket data:", data);
//                 setError("Invalid WebSocket data.");
//             }
//         });

//         socket.on("connect", () => {
//             console.log("WebSocket connected!");
//         });

//         socket.on("disconnect", () => {
//             console.log("WebSocket disconnected!");
//         });

//         socket.on("reconnect", (attempt) => {
//             console.log(`WebSocket reconnected after ${attempt} attempts`);
//         });

//         socket.on("connect_error", (err) => {
//             console.error("Socket connection error:", err.message || err);
//             setError("WebSocket connection failed. Check the console for details.");
//         });

//         socket.on("reconnect_failed", () => {
//             console.error("WebSocket reconnection failed");
//             setError("WebSocket reconnection failed. Please refresh the page.");
//         });

//         return () => {
//             socket.off("pnl_update");
//             socket.off("connect_error");
//             socket.off("connect");
//             socket.off("disconnect");
//             socket.off("reconnect");
//             socket.off("reconnect_failed");
//         };
//     }, []);

//     const totalEntryPrice = pnlData.reduce((sum, order) => sum + (order.entry_price || 0), 0);
//     const totalLatestPrice = pnlData.reduce((sum, order) => sum + (order.current_price || 0), 0);
//     const totalProfit = pnlData.filter(order => order.pnl > 0).reduce((sum, order) => sum + (order.pnl || 0), 0);
//     const totalLoss = pnlData.filter(order => order.pnl < 0).reduce((sum, order) => sum + Math.abs(order.pnl || 0), 0);
//     const netPnl = totalProfit - totalLoss;
//     const pnlPercentage = totalEntryPrice > 0 ? ((netPnl / totalEntryPrice) * 100).toFixed(2) : "0.00";

//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
//             {loading ? (
//                 <div className="flex justify-center items-center">
//                     <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
//                 </div>
//             ) : error ? (
//                 <div>
//                     <p className="text-red-500 font-semibold">{error}</p>
//                     <button
//                         onClick={fetchInitialData}
//                         className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
//                     >
//                         Retry
//                     </button>
//                 </div>
//             ) : (
//                 <div className="w-full max-w-5xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th>
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="8" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => (
//                                         <tr key={order.order_id} className="hover:bg-gray-700">
//                                             <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.entry_price?.toFixed(2) || "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.current_price?.toFixed(2) || "N/A"}
//                                             </td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold text-lg ${
//                                                     order.pnl >= 0 ? "text-green-500" : "text-red-500"
//                                                 }`}
//                                             >
//                                                 {order.pnl?.toFixed(2) || "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.pnl_percentage?.toFixed(2) || "N/A"}%
//                                             </td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                             <tfoot className="bg-gray-700 text-white font-bold">
//                                 <tr className="border-t border-gray-600">
//                                     <td className="px-12 py-3 text-right" colSpan="4">Total:</td>
//                                     <td className="px-4 py-3">{totalEntryPrice.toFixed(2)}</td>
//                                     <td className="px-4 py-3">{totalLatestPrice.toFixed(2)}</td>
//                                     <td className={`px-4 py-3 ${netPnl >= 0 ? "text-green-400" : "text-red-400"}`}>{netPnl.toFixed(2)}</td>
//                                     <td className="px-4 py-3">{pnlPercentage}%</td>
//                                     <td className="px-4 py-3">{netPnl >= 0 ? "Profit" : "Loss"}</td>
//                                 </tr>
//                             </tfoot>
//                         </table>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;


























// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";

// const socket = io("http://127.0.0.1:5000"); // Connect WebSocket to Flask backend

// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     // Fetch initial data from Flask API
//     const fetchInitialData = async () => {
//         try {
//             const response = await fetch("http://127.0.0.1:5000/api/pnl-report");
//             const data = await response.json();
//             if (data.status === "success" && Array.isArray(data.orders)) {
//                 setPnlData(data.orders); // Set API data
//             } else {
//                 setError("Invalid API response structure.");
//             }
//         } catch (err) {
//             setError("API request failed.");
//         }
//         setLoading(false);
//     };

//     useEffect(() => {
//         fetchInitialData();

//         // Listen for live PnL updates from WebSocket
//         socket.on("pnl_update", (data) => {
//             if (data.status === "success" && Array.isArray(data.pnl_report)) {
//                 setPnlData(data.pnl_report);
//             } else {
//                 setError("Invalid WebSocket data.");
//             }
//         });

//         socket.on("connect_error", (err) => {
//             console.error("Socket connection error:", err);
//             setError("WebSocket connection failed.");
//         });

//         return () => {
//             socket.off("pnl_update");
//             socket.off("connect_error");
//         };
//     }, []);

//     // Calculate total profit, total loss, and net PnL
//     const totalProfit = pnlData
//         .filter(order => order.pnl > 0)
//         .reduce((sum, order) => sum + (order.pnl || 0), 0)
//         .toFixed(2);

//     const totalLoss = pnlData
//         .filter(order => order.pnl < 0)
//         .reduce((sum, order) => sum + Math.abs(order.pnl || 0), 0)
//         .toFixed(2);

//     const netPnl = (totalProfit - totalLoss).toFixed(2);

//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
//             {loading ? (
//                 <p className="text-gray-300">Fetching data...</p>
//             ) : error ? (
//                 <p className="text-red-500 font-semibold">{error}</p>
//             ) : (
//                 <div className="w-full max-w-6xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th>
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                     <th className="px-4 py-2">Status</th> {/* New Column */}
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="9" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => (
//                                         <tr key={order.order_id} className="hover:bg-gray-700">
//                                             <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.entry_price !== undefined ? order.entry_price.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.current_price !== undefined ? order.current_price.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold text-lg ${
//                                                     order.pnl >= 0 ? "text-green-500" : "text-red-500"
//                                                 }`}
//                                             >
//                                                 {order.pnl !== undefined ? order.pnl.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.pnl_percentage !== undefined ? order.pnl_percentage.toFixed(2) : "N/A"}%
//                                             </td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold ${
//                                                     order.pnl >= 0 ? "text-green-400" : "text-red-400"
//                                                 }`}
//                                             >
//                                                 {order.pnl >= 0 ? "Profit" : "Loss"}
//                                             </td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                             {/* Footer Row for Total Profit & Loss */}
//                             <tfoot className="bg-gray-900 text-white text-lg font-bold">
//                                 <tr>
//                                     <td colSpan="6" className="px-4 py-3 text-right">Total Profit:</td>
//                                     <td className="px-4 py-3 text-green-500">{totalProfit}</td>
//                                     <td className="px-4 py-3"></td>
//                                     <td className="px-4 py-3"></td>
//                                 </tr>
//                                 <tr>
//                                     <td colSpan="6" className="px-4 py-3 text-right">Total Loss:</td>
//                                     <td className="px-4 py-3 text-red-500">-{totalLoss}</td>
//                                     <td className="px-4 py-3"></td>
//                                     <td className="px-4 py-3"></td>
//                                 </tr>
//                                 <tr>
//                                     <td colSpan="6" className="px-4 py-3 text-right">Net PnL:</td>
//                                     <td
//                                         className={`px-4 py-3 font-bold ${
//                                             netPnl >= 0 ? "text-green-400" : "text-red-400"
//                                         }`}
//                                     >
//                                         {netPnl}
//                                     </td>
//                                     <td className="px-4 py-3"></td>
//                                     <td className="px-4 py-3"></td>
//                                 </tr>
//                             </tfoot>
//                         </table>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;




// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";

// const socket = io("http://127.0.0.1:5000"); // Connect WebSocket to Flask backend

// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     // Fetch initial data from Flask API
//     const fetchInitialData = async () => {
//         try {
//             const response = await fetch("http://127.0.0.1:5000/api/pnl-report");
//             const data = await response.json();
//             if (data.status === "success" && Array.isArray(data.orders)) {
//                 setPnlData(data.orders); // Set API data
//             } else {
//                 setError("Invalid API response structure.");
//             }
//         } catch (err) {
//             setError("API request failed.");
//         }
//         setLoading(false);
//     };

//     useEffect(() => {
//         fetchInitialData();

//         // Listen for live PnL updates from WebSocket
//         socket.on("pnl_update", (data) => {
//             if (data.status === "success" && Array.isArray(data.pnl_report)) {
//                 setPnlData(data.pnl_report);
//             } else {
//                 setError("Invalid WebSocket data.");
//             }
//         });

//         socket.on("connect_error", (err) => {
//             console.error("Socket connection error:", err);
//             setError("WebSocket connection failed.");
//         });

//         return () => {
//             socket.off("pnl_update");
//             socket.off("connect_error");
//         };
//     }, []);

//     // Calculate totals for table columns
//     // const totalQuantity = pnlData.reduce((sum, order) => sum + (order.quantity || 0), 0);
//     const totalEntryPrice = pnlData.reduce((sum, order) => sum + (order.entry_price || 0), 0);
//     const totalLatestPrice = pnlData.reduce((sum, order) => sum + (order.current_price || 0), 0);
//     const totalProfit = pnlData.filter(order => order.pnl > 0).reduce((sum, order) => sum + (order.pnl || 0), 0);
//     const totalLoss = pnlData.filter(order => order.pnl < 0).reduce((sum, order) => sum + Math.abs(order.pnl || 0), 0);
//     const netPnl = totalProfit - totalLoss;
    
//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
//             {loading ? (
//                 <p className="text-gray-300">Fetching data...</p>
//             ) : error ? (
//                 <p className="text-red-300 font-semibold">{error}</p>
//             ) : (
//                 <div className="w-full max-w-6xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th>
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                     <th className="px-4 py-2">Status</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="9" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => (
//                                         <tr key={order.order_id} className="hover:bg-gray-700">
//                                             <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.entry_price !== undefined ? order.entry_price.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.current_price !== undefined ? order.current_price.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold text-lg ${
//                                                     order.pnl >= 0 ? "text-green-500" : "text-red-500"
//                                                 }`}
//                                             >
//                                                 {order.pnl !== undefined ? order.pnl.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.pnl_percentage !== undefined ? order.pnl_percentage.toFixed(2) : "N/A"}%
//                                             </td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold ${
//                                                     order.pnl >= 0 ? "text-green-400" : "text-red-400"
//                                                 }`}
//                                             >
//                                                 {order.pnl >= 0 ? "Profit" : "Loss"}
//                                             </td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                             {/* Footer Row for Totals */}
//                             <tfoot className="bg-gray-200 text-black font-bold">
//                                 <tr className="border-t border-gray-200 bg-gray-200">
//                                     <td className="px-12 py- text-right" colSpan="4">Total:</td>
//                                     {/* <td className="px-4 py-3">{totalQuantity}</td> */}
//                                     <td className="px-4 py-3">{totalEntryPrice.toFixed(2)}</td>
//                                     <td className="px-4 py-3">{totalLatestPrice.toFixed(2)}</td>
//                                     <td className={`px-4 py-3 ${netPnl >= 0 ? "text-green-400" : "text-red-400"}`}>
//                                         {netPnl.toFixed(2)}
//                                     </td>
//                                     <td className="px-4 py-3">{totalEntryPrice.toFixed(2)}</td>
//                                     <td className="px-4 py-3">loss</td>
//                                 </tr>
//                             </tfoot>
//                         </table>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;






// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";

// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     useEffect(() => {
//         const socket = io("http://127.0.0.1:5000", {
//             reconnectionAttempts: 5, // Try reconnecting 5 times
//             reconnectionDelay: 2000, // Wait 2 seconds before retry
//         });

//         // Fetch initial PnL data
//         const fetchInitialData = async () => {
//             try {
//                 const response = await fetch("http://127.0.0.1:5000/api/pnl-report");
//                 const data = await response.json();
//                 if (data.status === "success" && Array.isArray(data.orders)) {
//                     setPnlData(data.orders); // Set initial API data
//                 } else {
//                     setError("Invalid API response structure.");
//                 }
//             } catch (err) {
//                 setError("API request failed.");
//             }
//             setLoading(false);
//         };

//         fetchInitialData();

//         // Listen for real-time PnL updates from WebSocket
//         socket.on("pnl_update", (data) => {
//             if (data.status === "success" && Array.isArray(data.pnl_report)) {
//                 setPnlData(data.pnl_report);
//             } else {
//                 setError("Invalid WebSocket data.");
//             }
//         });

//         // Handle WebSocket errors
//         socket.on("connect_error", (err) => {
//             console.error("Socket connection error:", err);
//             setError("WebSocket connection failed.");
//         });

//         // Cleanup WebSocket connection on unmount
//         return () => {
//             socket.disconnect();
//         };
//     }, []);

//     // Total PnL Calculations
//     const totalEntryPrice = pnlData.reduce((sum, order) => sum + (order.entry_price || 0), 0);
//     const totalLatestPrice = pnlData.reduce((sum, order) => sum + (order.current_price || 0), 0);
//     const totalProfit = pnlData.filter(order => order.pnl > 0).reduce((sum, order) => sum + (order.pnl || 0), 0);
//     const totalLoss = pnlData.filter(order => order.pnl < 0).reduce((sum, order) => sum + Math.abs(order.pnl || 0), 0);
//     const netPnl = totalProfit - totalLoss;
//     const pnlPercentage = totalEntryPrice > 0 ? ((netPnl / totalEntryPrice) * 100).toFixed(2) : "0.00";

//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
//             {loading ? (
//                 <p className="text-gray-300">Fetching data...</p>
//             ) : error ? (
//                 <p className="text-red-300 font-semibold">{error}</p>
//             ) : (
//                 <div className="w-full max-w-6xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th>
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                     <th className="px-4 py-2">Status</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="9" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => (
//                                         <tr key={order.order_id} className="hover:bg-gray-700">
//                                             <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.entry_price !== undefined ? order.entry_price.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.current_price !== undefined ? order.current_price.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold text-lg ${
//                                                     order.pnl >= 0 ? "text-green-500" : "text-red-500"
//                                                 }`}
//                                             >
//                                                 {order.pnl !== undefined ? order.pnl.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.pnl_percentage !== undefined ? order.pnl_percentage.toFixed(2) : "N/A"}%
//                                             </td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold ${
//                                                     order.pnl >= 0 ? "text-green-400" : "text-red-400"
//                                                 }`}
//                                             >
//                                                 {order.pnl >= 0 ? "Profit" : "Loss"}
//                                             </td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                             {/* Footer Row for Totals */}
//                             <tfoot className="bg-gray-200 text-black font-bold">
//                                 <tr className="border-t border-gray-200 bg-gray-200">
//                                     <td className="px-12 py- text-right" colSpan="4">Total:</td>
//                                     <td className="px-4 py-3">{totalEntryPrice.toFixed(2)}</td>
//                                     <td className="px-4 py-3">{totalLatestPrice.toFixed(2)}</td>
//                                     <td className={`px-4 py-3 ${netPnl >= 0 ? "text-green-400" : "text-red-400"}`}>
//                                         {netPnl.toFixed(2)}
//                                     </td>
//                                     <td className="px-4 py-3">{pnlPercentage}%</td>
//                                     <td className="px-4 py-3">{netPnl >= 0 ? "Profit" : "Loss"}</td>
//                                 </tr>
//                             </tfoot>
//                         </table>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;






// import React, { useEffect, useState } from "react";
// import { io } from "socket.io-client";

// const PnlReport = () => {
//     const [pnlData, setPnlData] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     useEffect(() => {
//         const socket = io("http://127.0.0.1:5000", {
//             reconnectionAttempts: 5,
//             reconnectionDelay: 2000,
//         });

//         const fetchInitialData = async () => {
//             try {
//                 const response = await fetch("http://127.0.0.1:5000/api/pnl-report");
//                 const data = await response.json();
//                 if (data.status === "success" && Array.isArray(data.orders)) {
//                     setPnlData(data.orders);
//                 } else {
//                     setError("Invalid API response structure.");
//                 }
//             } catch (err) {
//                 setError("API request failed.");
//             }
//             setLoading(false);
//         };

//         fetchInitialData();

//         socket.on("pnl_update", (data) => {
//             if (data.status === "success" && Array.isArray(data.pnl_report)) {
//                 setPnlData(data.pnl_report);
//             } else {
//                 setError("Invalid WebSocket data.");
//             }
//         });

//         socket.on("connect_error", (err) => {
//             console.error("Socket connection error:", err);
//             setError("WebSocket connection failed.");
//         });

//         return () => {
//             socket.disconnect();
//         };
//     }, []);

//     const totalEntryPrice = pnlData.reduce((sum, order) => sum + (order.entry_price || 0), 0);
//     const totalLatestPrice = pnlData.reduce((sum, order) => sum + (order.current_price || 0), 0);
//     const totalProfit = pnlData.filter(order => order.pnl > 0).reduce((sum, order) => sum + (order.pnl || 0), 0);
//     const totalLoss = pnlData.filter(order => order.pnl < 0).reduce((sum, order) => sum + Math.abs(order.pnl || 0), 0);
//     const netPnl = totalProfit - totalLoss;
//     const pnlPercentage = totalEntryPrice > 0 ? ((netPnl / totalEntryPrice) * 100).toFixed(2) : "0.00";

//     return (
//         <div className="p-6 bg-gray-900 min-h-screen flex flex-col items-center text-white">
//             <h2 className="text-2xl font-bold mb-4">📊 Live PnL Report</h2>
//             {loading ? (
//                 <p className="text-gray-300">Fetching data...</p>
//             ) : error ? (
//                 <p className="text-red-300 font-semibold">{error}</p>
//             ) : (
//                 <div className="w-full max-w-6xl bg-gray-800 shadow-md rounded-lg overflow-hidden">
//                     <div className="overflow-x-auto">
//                         <table className="w-full text-sm text-gray-300">
//                             <thead className="bg-blue-600 text-white uppercase text-xs">
//                                 <tr>
//                                     <th className="px-4 py-2">Order ID</th>
//                                     <th className="px-4 py-2">Security ID</th>
//                                     <th className="px-4 py-2">Type</th>
//                                     <th className="px-4 py-2">Quantity</th>
//                                     <th className="px-4 py-2">Entry Price</th>
//                                     <th className="px-4 py-2">Latest Price</th>
//                                     <th className="px-4 py-2">PnL</th>
//                                     <th className="px-4 py-2">PnL %</th>
//                                     <th className="px-4 py-2">Status</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="divide-y divide-gray-700">
//                                 {pnlData.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="9" className="p-4 text-center text-gray-500">
//                                             No orders available.
//                                         </td>
//                                     </tr>
//                                 ) : (
//                                     pnlData.map((order) => (
//                                         <tr key={order.order_id} className="hover:bg-gray-700">
//                                             <td className="px-4 py-2">{order.order_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.security_id || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.transaction_type || "N/A"}</td>
//                                             <td className="px-4 py-2">{order.quantity || "N/A"}</td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.entry_price !== undefined ? order.entry_price.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.current_price !== undefined ? order.current_price.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold text-lg ${
//                                                     order.pnl >= 0 ? "text-green-500" : "text-red-500"
//                                                 }`}
//                                             >
//                                                 {order.pnl !== undefined ? order.pnl.toFixed(2) : "N/A"}
//                                             </td>
//                                             <td className="px-4 py-2 font-semibold">
//                                                 {order.pnl_percentage !== undefined ? order.pnl_percentage.toFixed(2) : "N/A"}%
//                                             </td>
//                                             <td
//                                                 className={`px-4 py-2 font-bold ${
//                                                     order.pnl >= 0 ? "text-green-400" : "text-red-400"
//                                                 }`}
//                                             >
//                                                 {order.pnl >= 0 ? "Profit" : "Loss"}
//                                             </td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                             <tfoot className="bg-gray-200 text-black font-bold">
//                                 <tr className="border-t border-gray-200 bg-gray-200">
//                                     <td className="px-12 py-3 text-right" colSpan="4">Total:</td>
//                                     <td className="px-4 py-3">{totalEntryPrice.toFixed(2)}</td>
//                                     <td className="px-4 py-3">{totalLatestPrice.toFixed(2)}</td>
//                                     <td className={`px-4 py-3 ${netPnl >= 0 ? "text-green-400" : "text-red-400"}`}>{netPnl.toFixed(2)}</td>
//                                     <td className="px-4 py-3">{pnlPercentage}%</td>
//                                     <td className="px-4 py-3">{netPnl >= 0 ? "Profit" : "Loss"}</td>
//                                 </tr>
//                             </tfoot>
//                         </table>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default PnlReport;
